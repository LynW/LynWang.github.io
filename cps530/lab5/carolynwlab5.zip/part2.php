<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Lab 5 Part 2</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css" media="screen" title="no title" charset="utf-8">
</head>
<body>

  <div class="container">


    <form action="http://webdev.scs.ryerson.ca:8080/c54wang/test.asp" method="post">
      Image Url: <input name="image" type="text">
      <br><br>
      <input type="radio" name="texture" value="norepeat"> No-Repeat
      <br><br>
      <input type="radio" name="texture" value="fixed"> Fixed
      <br><br><br>
      <input type="submit" />
    </form>

  </div>

</body>
</html>
