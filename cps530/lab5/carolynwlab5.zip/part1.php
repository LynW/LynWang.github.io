<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
<link rel="stylesheet" href="style.css" media="screen" title="no title" charset="utf-8">

<body>
  Please enter a number from 3 to 12.
  <form method="post" action="process.php"
  <strong>Enter Numbers:</strong>
  <input type="text" name="num1" size="2">
  x
  <input type="text" name="num2" size="2">
  <input type="submit" value="Get Table">
</form>

<br><br>


</body>
